#Author: xNot_Found

#DiRecodeGakBakalJadiinLuMastah

#DiGantiAuthorGakBakalJadiinLuMaster

#MikirMakeOtakGblk

#KaloMauReedit/Recode

#Minta Izin Dulu

*Install Tool*
```bash
$ apt update && apt upgrade
$ pkg install git figlet toilet
$ pip2 install lolcat
$ git clone https://github.com/hatakecnk/xNot_Found.git
```

*Open The Tool*
```bash
$ cd xNot_Found
$ chmod +x xNot_Found.py
$ python2 xNot_Found.py
```

*SILAHKAN HUBUNGI KONTAK DIBAWAH UNTUK INFO LEBIH LANJUT :)*

*CONTACT ME*
```bash
Email : febryafriansyah@programmer.net
Whatsapp : +62823-8637-2115
LINE ID  : hatakecnk
Facebook : https://m.facebook.com/hatakecnk
```
