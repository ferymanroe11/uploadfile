clear
echo "[+] Tool Menu Page 3 Sedang Dalam Pembangunan"
sleep 1
echo "[+] Maaf Atas Ketidaknyaman Anda Dalam Menggunakan Tool Kami"
sleep 1
echo "[+] Kami Akan Membuat Menu Page 3 Secepatnya"
sleep 1
echo "[+] Terima Kasih :)"
sleep 1
echo "[+] Kami Akan Mengarahkan Anda Kembali Ke Menu Tool Page 2"
echo "\033[31;1mTap Enter To Continue"
read enter
sh xNot_Found2.sh